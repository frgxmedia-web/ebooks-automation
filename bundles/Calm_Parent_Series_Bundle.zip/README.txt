Thank you for your purchase!
==================================================

10 - The Calm Parent Series — Complete 10-Book Bundle

WHAT'S INCLUDED
  01. 01 - The Regulated Parent.pdf
  02. 02 - Raising Emotionally Intelligent Kids.pdf
  03. 03 - Screens Social Media and the Developing Brain.pdf
  04. 04 - Discipline That Doesn't Break the Relationship.pdf
  05. 05 - Raising Kids Who Can Fail.pdf
  06. 06 - Parenting the Anxious Child.pdf
  07. 07 - Talking to Kids About Hard Topics.pdf
  08. 08 - The Teenage Brain.pdf
  09. 09 - Single Parenting With Intention.pdf
  10. 10 - Mindful Parenting.pdf

HOW TO READ
- Open any PDF with Adobe Acrobat, Preview (Mac),
  or any free PDF reader
- All files are print-ready (6x9 inches, 300 DPI)

IMPORTANT
These books are for educational purposes only.
They are not a substitute for professional,
medical, financial, or legal advice.

Questions? Contact us via Gumroad.
==================================================
