Thank you for your purchase!
==================================================

7 - The Inner Healing Series — Complete 10-Book Bundle

WHAT'S INCLUDED
  01. 01 - Healing After Childhood Wounds.pdf
  02. 02 - The Boundaries Blueprint.pdf
  03. 03 - Self-Compassion in Practice.pdf
  04. 04 - Anger Understanding the Fire Within.pdf
  05. 05 - Loneliness and the Art of Connection.pdf
  06. 06 - The Highly Sensitive Person's Guide to Thriving.pdf
  07. 07 - Forgiveness Is for You.pdf
  08. 08 - Emotional Intelligence at Work and Home.pdf
  09. 09 - Finding Purpose After Loss.pdf
  10. 10 - The Anxiety Reset.pdf

HOW TO READ
- Open any PDF with Adobe Acrobat, Preview (Mac),
  or any free PDF reader
- All files are print-ready (6x9 inches, 300 DPI)

IMPORTANT
These books are for educational purposes only.
They are not a substitute for professional,
medical, financial, or legal advice.

Questions? Contact us via Gumroad.
==================================================
