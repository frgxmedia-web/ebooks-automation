Thank you for your purchase!
==================================================

4 - The Money Healing Series — Complete 10-Book Bundle

WHAT'S INCLUDED
  01. 01 - The Scarcity Mindset Fix.pdf
  02. 02 - Debt Without Shame.pdf
  03. 03 - First-Generation Wealth.pdf
  04. 04 - The Emotional Spender.pdf
  05. 05 - Side Income Without Burnout.pdf
  06. 06 - Money and Mental Health.pdf
  07. 07 - Negotiating Your Worth.pdf
  08. 08 - The Minimalist Budget.pdf
  09. 09 - Investing for People Who Don't Trust the Market.pdf
  10. 10 - Couples and Money.pdf

HOW TO READ
- Open any PDF with Adobe Acrobat, Preview (Mac),
  or any free PDF reader
- All files are print-ready (6x9 inches, 300 DPI)

IMPORTANT
These books are for educational purposes only.
They are not a substitute for professional,
medical, financial, or legal advice.

Questions? Contact us via Gumroad.
==================================================
