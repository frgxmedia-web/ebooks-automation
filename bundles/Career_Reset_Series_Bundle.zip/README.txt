Thank you for your purchase!
==================================================

8 - The Career Reset Series — Complete 10-Book Bundle

WHAT'S INCLUDED
  01. 01 - Burned Out and Starting Over.pdf
  02. 02 - The Introverted Professional.pdf
  03. 03 - Negotiating at Every Career Stage.pdf
  04. 04 - Remote Work Mastery.pdf
  05. 05 - The Career in Your 40s.pdf
  06. 06 - Building a Personal Brand That Actually Works.pdf
  07. 07 - Difficult Conversations at Work.pdf
  08. 08 - Leadership Without Authority.pdf
  09. 09 - The Consultant Mindset.pdf
  10. 10 - Work-Life Integration.pdf

HOW TO READ
- Open any PDF with Adobe Acrobat, Preview (Mac),
  or any free PDF reader
- All files are print-ready (6x9 inches, 300 DPI)

IMPORTANT
These books are for educational purposes only.
They are not a substitute for professional,
medical, financial, or legal advice.

Questions? Contact us via Gumroad.
==================================================
