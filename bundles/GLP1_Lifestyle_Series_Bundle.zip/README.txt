Thank you for your purchase!
==================================================

2 - The GLP-1 Lifestyle Series — Complete 10-Book Bundle

WHAT'S INCLUDED
  01. 01 - The GLP-1 Nutrition Guide.pdf
  02. 02 - GLP-1 for Women Over 40.pdf
  03. 03 - Managing GLP-1 Side Effects.pdf
  04. 04 - GLP-1 and Strength Training.pdf
  05. 05 - The GLP-1 Meal Prep Playbook.pdf
  06. 06 - GLP-1 for Long-Term Success.pdf
  07. 07 - Hair Loss on GLP-1.pdf
  08. 08 - GLP-1 and Mental Health.pdf
  09. 09 - GLP-1 on a Budget.pdf
  10. 10 - The GLP-1 Fasting Protocol.pdf

HOW TO READ
- Open any PDF with Adobe Acrobat, Preview (Mac),
  or any free PDF reader
- All files are print-ready (6x9 inches, 300 DPI)

IMPORTANT
These books are for educational purposes only.
They are not a substitute for professional,
medical, financial, or legal advice.

Questions? Contact us via Gumroad.
==================================================
