Thank you for your purchase!
==================================================

1 - The Somatic Reset Series — Complete 10-Book Bundle

WHAT'S INCLUDED
  01. 01 - The Vagus Nerve Reset.pdf
  02. 02 - Somatic Exercises for Anxiety.pdf
  03. 03 - The Dopamine Reset.pdf
  04. 04 - Nervous System Healing for Burnout.pdf
  05. 05 - Sleep & the Nervous System.pdf
  06. 06 - Somatic Tools for Grief.pdf
  07. 07 - The ADHD Nervous System.pdf
  08. 08 - Chronic Pain & the Nervous System.pdf
  09. 09 - Trauma Release for Beginners.pdf
  10. 10 - Somatic Healing for Perimenopause.pdf

HOW TO READ
- Open any PDF with Adobe Acrobat, Preview (Mac),
  or any free PDF reader
- All files are print-ready (6x9 inches, 300 DPI)

IMPORTANT
These books are for educational purposes only.
They are not a substitute for professional,
medical, financial, or legal advice.

Questions? Contact us via Gumroad.
==================================================
