Thank you for your purchase!
==================================================

9 - The Relationship Reset Series — Complete 10-Book Bundle

WHAT'S INCLUDED
  01. 01 - Attachment Styles and Why You Love the Way You Do.pdf
  02. 02 - Communication That Actually Connects.pdf
  03. 03 - Recovering From Infidelity.pdf
  04. 04 - The Art of Healthy Conflict.pdf
  05. 05 - Loving Someone With Anxiety.pdf
  06. 06 - Rebuilding Trust.pdf
  07. 07 - Intimacy After Trauma.pdf
  08. 08 - Parenting as Partners.pdf
  09. 09 - Dating After 35.pdf
  10. 10 - When to Leave and When to Stay.pdf

HOW TO READ
- Open any PDF with Adobe Acrobat, Preview (Mac),
  or any free PDF reader
- All files are print-ready (6x9 inches, 300 DPI)

IMPORTANT
These books are for educational purposes only.
They are not a substitute for professional,
medical, financial, or legal advice.

Questions? Contact us via Gumroad.
==================================================
