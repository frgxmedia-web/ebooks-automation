Thank you for your purchase!
==================================================

5 - The Hormone Reset Series — Complete 10-Book Bundle

WHAT'S INCLUDED
  01. 01 - Cortisol and the Body Under Stress.pdf
  02. 02 - Estrogen in Balance.pdf
  03. 03 - Thyroid Health Simplified.pdf
  04. 04 - Perimenopause Without Panic.pdf
  05. 05 - Insulin Resistance Explained.pdf
  06. 06 - Testosterone for Women.pdf
  07. 07 - Gut Hormones and the Hunger Code.pdf
  08. 08 - Cycle Syncing.pdf
  09. 09 - Men's Hormonal Health.pdf
  10. 10 - Hormones After 50.pdf

HOW TO READ
- Open any PDF with Adobe Acrobat, Preview (Mac),
  or any free PDF reader
- All files are print-ready (6x9 inches, 300 DPI)

IMPORTANT
These books are for educational purposes only.
They are not a substitute for professional,
medical, financial, or legal advice.

Questions? Contact us via Gumroad.
==================================================
